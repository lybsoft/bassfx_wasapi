lybBass FX v0.1

This software helps add psuedo-bass on speakers that can't handle low frequencies.
You will need a dummy sound device that didn't output to any speaker to work.
Something like Virtual Audio Cable or VoiceMeeter Banana would work.
Make sure to set the audio device correctly to avoid loud feedback noise.

Usage :
1. Set a dummy playback device as default.
2. Use the configurator or guess the device number on the cfg.ini, make sure to set the volume at a really low value on all sound device to avoid potentially dangerous loud feedback noise. Make sure the freq value matches your sound device's Sample Rate on the cfg.ini!
3. Run the software, if the sound didn't come up or feedback noise happens guess the device number again.
4. If it works, refer to the guide below on how to set up the optimal value for your sound device.

cfg.ini How To

[config]
device=3 //Output Sound Device ID Number based on the Configurator, Starts from 0

pass1=80 //LPass for FX Channel 1
pass2=80 //LPass for FX Channel 2

pass2e=1 OR pass2e=0
Enable or Disable FX Channel 2 to save CPU Time

freq=48000 //Your current Sample Rate, make sure it matches!

Example Configurations :
Crappy Earbuds or 2.1 Speakers
FX Channel 1 = 46
FX Channel 2 = 23

Laptop Speaker Variant 1
FX Channel 1 = 80
FX Channel 2 = 80

Laptop Speaker Variant 2
FX Channel 1 = 125
FX Channel 2 = 125

Other editable value on cfg.ini is experimental and untested. It's best to leave it alone as is unless you know what you're doing.